package MineGame;

import org.junit.Test;

public class MineSweeperTests {

    @Test
    public void Invalid_Input_OutOfBounds() {

    }
}
