package MineGame;

import java.util.Random;
import java.util.Scanner;

public class MineSweeper {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.printf("Enter Difficulty Level%n");
        System.out.printf("Press 0 for BEGINNER (9 * 9 Cells and 10 Mines)%n");
        System.out.printf("Press 1 for INTERMEDIATE (16 * 16 Cells and 40 Mines)%n");
        System.out.printf("Press 2 for ADVANCED (24 * 24 Cells and 90 Mines)%n");

        int diffNumber = Integer.parseInt(scan.nextLine());
        int numberOfCells = 0;

        if (diffNumber == 0) {
            numberOfCells = 9;
        } else if (diffNumber == 1) {
            numberOfCells = 16;
        } else if (diffNumber == 2) {
            numberOfCells = 24;
        } else {
            throw new IllegalArgumentException("Invalid number for level difficulty (" + diffNumber + ")!");
        }

        char[][] field = new char[numberOfCells][numberOfCells];
        boolean[][] mines = new boolean[numberOfCells][numberOfCells];

        fillField(field);
        fillMines(mines, numberOfCells);

        printMatrix(field);

        while (true) {

            System.out.print("Enter your move, ");
            int rowFromUser = scan.nextInt();
            int colFromUser = scan.nextInt();
            System.out.println("->");

            if (!isOutOfBounds(field, rowFromUser, colFromUser)) {
                if (!mines[rowFromUser][colFromUser]) {
                    int numOfBombs = closeMines(mines, rowFromUser, colFromUser);
                    field[rowFromUser][colFromUser] = Character.forDigit(numOfBombs, 10);
                    printMatrix(revealFields(mines, field, rowFromUser, colFromUser));
                } else {
                    System.out.println("You lost! Want to play again?");
                    return;
                }
            } else {
                System.out.println("Indexes are out of bounds!");
            }
        }
    }

    private static void printMatrix(char[][] matrix) {
        System.out.println("Current Status of Board :");
        System.out.print("    ");

        for (int i = 0; i < matrix.length; i++) {
            System.out.print(i + " ");
        }

        System.out.println();

        for (int row = 0; row < matrix.length; row++) {
            System.out.print(row + "   ");
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println();
        }
    }

    private static char[][] fillField(char[][] matrix) {
        for (int col = 0; col < matrix[0].length; col++) {
            for (int row = 0; row < matrix.length; row++) {
                matrix[row][col] = '-';
            }
        }
        return matrix;
    }

    private static boolean[][] fillMines(boolean[][] matrix, int bound) {
        for (int col = 0; col < matrix[0].length; col++) {
            for (int row = 0; row < matrix.length; row++) {
                matrix[row][col] = false;
            }
        }

        mines(matrix, bound);


        return matrix;
    }

    private static void mines(boolean[][] matrix, int bound) {
        Random random = new Random();
        if (bound == 9) {
            for (int i = 1; i <= 10; i++) {
                int row = random.nextInt(bound);
                int col = random.nextInt(bound);
                if (matrix[row][col]) {
                    i--;
                } else {
                    matrix[row][col] = true;
                }
            }
        } else if (bound == 16) {
            for (int i = 1; i <= 40; i++) {
                int row = random.nextInt(bound);
                int col = random.nextInt(bound);
                if (matrix[row][col]) {
                    i--;
                } else {
                    matrix[row][col] = true;
                }
            }
        } else if (bound == 24) {
            for (int i = 1; i <= 90; i++) {
                int row = random.nextInt(bound);
                int col = random.nextInt(bound);
                if (matrix[row][col]) {
                    i--;
                } else {
                    matrix[row][col] = true;
                }
            }
        }
    }

    private static boolean isOutOfBounds(char[][] matrix, int row, int col) {
        return row < 0 || row >= matrix.length || col < 0 || col >= matrix[row].length;
    }

    private static boolean isOutOfBounds(boolean[][] matrix, int row, int col) {
        return row < 0 || row >= matrix.length || col < 0 || col >= matrix[row].length;
    }

    private static int closeMines(boolean[][] mines, int x, int y) {
        int result = 0;

        if (isOutOfBounds(mines, x - 1, y - 1)) {
            result++;
        }
        if (isOutOfBounds(mines, x - 1, y)) {
            result++;
        }
        if (isOutOfBounds(mines, x - 1, y + 1)) {
            result++;
        }
        if (isOutOfBounds(mines, x, y + 1)) {
            result++;
        }
        if (isOutOfBounds(mines, x + 1, y + 1)) {
            result++;
        }
        if (isOutOfBounds(mines, x + 1, y)) {
            result++;
        }
        if (isOutOfBounds(mines, x + 1, y - 1)) {
            result++;
        }
        if (isOutOfBounds(mines, x, y - 1)) {
            result++;
        }
        return result;
    }

    private static char[][] revealFields(boolean[][] mines, char[][] field, int x, int y) {

        if (!mines[x - 1][y - 1] && !isOutOfBounds(mines, x - 1, y - 1)) {
            if (!isDigit(field[x - 1][y - 1])) {
                field[x - 1][y - 1] = '*';
            }

        }
        if (!mines[x - 1][y] && !isOutOfBounds(mines, x - 1, y)) {
            if (!isDigit(field[x - 1][y])) {
                field[x - 1][y] = '*';
            }
        }
        if (!mines[x - 1][y + 1] && !isOutOfBounds(mines, x - 1, y + 1)) {
            if (!isDigit(field[x - 1][y + 1])) {
                field[x - 1][y + 1] = '*';
            }
        }
        if (!mines[x][y + 1] && !isOutOfBounds(mines, x, y + 1)) {
            if (!isDigit(field[x][y + 1])) {
                field[x][y + 1] = '*';
            }
        }
        if (!mines[x + 1][y + 1] && !isOutOfBounds(mines, x + 1, y + 1)) {
            if (!isDigit(field[x + 1][y + 1])) {
                field[x + 1][y + 1] = '*';
            }
        }
        if (!mines[x + 1][y] && !isOutOfBounds(mines, x + 1, y)) {
            if (!isDigit(field[x + 1][y])) {
                field[x + 1][y] = '*';
            }
        }
        if (!mines[x + 1][y - 1] && !isOutOfBounds(mines, x + 1, y - 1)) {
            if (!isDigit(field[x + 1][y - 1])) {
                field[x + 1][y - 1] = '*';
            }
        }
        if (!mines[x][y - 1] && !isOutOfBounds(mines, x, y - 1)) {
            if (!isDigit(field[x][y - 1])) {
                field[x][y - 1] = '*';
            }
        }
        return field;
    }

    private static boolean isDigit(char c) {
        return (c >= '0' && c <= '9');
    }
}
